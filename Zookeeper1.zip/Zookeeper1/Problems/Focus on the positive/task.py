# Please don't modify this code
# `a` stores an input value
a = int(input().strip())

# put your code here
result = (a > 0)
print(result)
