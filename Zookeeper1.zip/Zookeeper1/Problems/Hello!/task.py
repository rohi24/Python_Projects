user = input()
print('Hello, '+user)