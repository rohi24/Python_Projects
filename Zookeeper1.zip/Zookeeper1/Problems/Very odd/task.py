A = abs(int(input()))
B = abs(int(input()))

result = (A // B)
print(result % 2 != 0)
