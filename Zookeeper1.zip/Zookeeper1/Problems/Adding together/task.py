a = int(input())
b = int(input())

# calculate the sum below
print(a + b)
