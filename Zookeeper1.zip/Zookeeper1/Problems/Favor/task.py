k = int(input())
n = 0

while k > 0:
    n += k
    k -= 1
print(n)
