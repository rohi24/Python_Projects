# put your python code here
print(1234567890 * 987654321 + 67890)