num_1 = int(input())
num_2 = int(input())
num_3 = int(input())

result = (num_1 < num_2 < num_3)
print(result)
