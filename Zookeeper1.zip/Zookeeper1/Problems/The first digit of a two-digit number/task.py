# put your python code here
number = abs(int(input()))

result = int(number // 10)
print(result)
