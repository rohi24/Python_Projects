numbers = [0, 1, 2, 3, 4, 5]
# put your python code here
print(numbers)