n1 = int(input())
n2 = int(input())
diff = int(n1) - int(n2)
print(diff)
