# prints "ok" without quotes
print("ok")