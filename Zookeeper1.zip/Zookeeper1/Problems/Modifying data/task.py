# change the name of the 5th planet in planets
planets[4] = 'Jupiter'