n1 = float(input())
n2 = float(input())
add = float(n1) + float(n2)
print(add)
