n = int(input())
i = 2
while n > i:
    print(i)
    i += 2
