# put your python code here
a = int(input())
b = int(input())
c = int(input())

s = 4 * (a + b + c)

S = 2 * (a * b + b * c + a * c)

V = a * b * c

print(s)
print(S)
print(V)
