#create a variable x
#with the value 8
x = 8
x = x * x
print(x) #prints the x squared