# put your python code here
n = int(input())

result = int(((n + 1) * n + 2) * n + 3)
print(result)