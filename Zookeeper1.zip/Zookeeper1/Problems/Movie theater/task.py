# put your python code here
N = int(input())
K = int(input())
V = int(input())

total = int(N * K)
result = (V <= total)
print(result)
