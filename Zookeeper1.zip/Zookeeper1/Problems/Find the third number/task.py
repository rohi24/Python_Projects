prices = input().split()  # this is the list to work with

element = prices[2]
print(element)