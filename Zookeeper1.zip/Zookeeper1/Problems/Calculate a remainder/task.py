# put your python code here
print(10 % 3)