# work with these variables
a = int(input())
b = int(input())
c = int(input())

mul = int(a * b - c)

print(mul)