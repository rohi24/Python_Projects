print(type("int"))
print(type(394))
print(type(2.71))