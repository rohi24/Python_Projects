alphabet = 'abcdefghijklmnopqrstuvwxyz'
letter = alphabet[14]
print(letter)