print('''"""
THIS IS A STRING
"""
''')