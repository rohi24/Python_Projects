http_response = 'mocked response'
http_error = 404
