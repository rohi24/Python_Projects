# copy the correct variables here
model_score = 0.9875
client_name = "Bob"
