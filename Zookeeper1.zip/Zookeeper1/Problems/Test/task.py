# put your python code here
data = input()
print(data)