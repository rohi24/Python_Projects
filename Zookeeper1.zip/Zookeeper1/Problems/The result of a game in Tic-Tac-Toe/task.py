print("O X X")
print("O X O")
print("X O X")