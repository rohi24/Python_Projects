# put your python code here
N = abs(int(input()))
K = abs(int(input()))

result = int(K % N)

print(result)