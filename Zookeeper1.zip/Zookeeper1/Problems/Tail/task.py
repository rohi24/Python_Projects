# print the last symbol of the predefined variable `sente
print(sentence[-1])