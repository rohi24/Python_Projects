balance = int(input())
years = 0
while balance < 700000:
    balance = (balance * 1.071)
    years += 1
print(years)