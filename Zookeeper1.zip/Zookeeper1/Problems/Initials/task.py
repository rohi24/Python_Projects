# the following line reads the name from the input, do not modify it, please
name = input()

letter = name[0]
print(letter)