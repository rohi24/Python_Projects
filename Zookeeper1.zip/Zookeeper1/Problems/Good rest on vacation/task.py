# put your python code here
days = abs(int(input()))
cost_per_day = abs(int(input()))
flight_cost = abs(int(input()))
hotel_cost = abs(int(input()))

food_cost = int(cost_per_day * days)
flight_cost = int(flight_cost * 2)
nights = int(days - 1)
hotel_cost = int(hotel_cost * nights)

total_cost = int(food_cost + flight_cost + hotel_cost)
print(total_cost)
