i = 1
while i <= 20:
    print(i ** 2)
    i += 1
