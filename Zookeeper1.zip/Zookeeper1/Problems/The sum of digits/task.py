# put your python code here
number = input()

print(sum(map(int, number)))
