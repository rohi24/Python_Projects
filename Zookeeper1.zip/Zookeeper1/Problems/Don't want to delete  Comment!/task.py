#print(1 + 2 + 3 + 6)
print(1 + 3 + 3)
#print(1 + 2 + 3)