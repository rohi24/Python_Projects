print("Learn Python to be great!")
