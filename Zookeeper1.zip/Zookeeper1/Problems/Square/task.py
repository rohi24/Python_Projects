print("* * * *")
print("*     *")
print("*     *")
print("* * * *")