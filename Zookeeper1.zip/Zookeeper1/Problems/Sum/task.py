# put your python code here
number1 = int(input())
number2 = int(input())
number3 = int(input())
sumar = int(number1) + int(number2) + int(number3)
print(sumar)
