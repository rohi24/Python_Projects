amount = 1000
interest_rate = 5
years = 1
# change the next line
income = (amount * interest_rate * years) / 100
