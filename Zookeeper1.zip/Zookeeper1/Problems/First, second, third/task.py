print("first")
print("second")
print("third")