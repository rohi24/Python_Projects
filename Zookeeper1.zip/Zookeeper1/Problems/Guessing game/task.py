set_number = 6557
num_1 = int(input())
num_2 = int(input())

mul = int(num_1 * num_2)

result = (set_number == mul)
print(result)
