# the variable `coin` is already defined
if coin:
    print("Welcome to Charon's boat!")

print("There is no turning back.")
