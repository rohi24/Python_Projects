# put your python code here
print(31 ** 331 % 20)