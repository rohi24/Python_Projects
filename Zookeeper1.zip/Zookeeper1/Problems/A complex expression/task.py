n = int(input())

add = int(n) + int(n)
mul = int(add) * int(n)
sub = int(mul) - int(n)
div = int(sub) // int(n)

print(div)