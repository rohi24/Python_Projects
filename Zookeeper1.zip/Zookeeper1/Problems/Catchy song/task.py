n = int(input())
user = input()
print(user * n)