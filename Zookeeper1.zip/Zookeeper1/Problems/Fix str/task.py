str_ = "Hello"
str_ = str_ + str(10)
